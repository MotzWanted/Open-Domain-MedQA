class Embedder(ABC):
    """
    Abstract class for all the embedders
    """