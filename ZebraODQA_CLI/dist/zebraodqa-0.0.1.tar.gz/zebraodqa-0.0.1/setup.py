# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['zebraodqa', 'zebraodqa.commands', 'zebraodqa.scripts', 'zebraodqa.system']

package_data = \
{'': ['*']}

install_requires = \
['alive-progress>=1.6.2,<2.0.0',
 'confuse>=1.4.0,<2.0.0',
 'datasets>=1.6.2,<2.0.0',
 'faiss-cpu>=1.7.0,<2.0.0',
 'torch>=1.8.1,<2.0.0',
 'transformers>=4.5.1,<5.0.0',
 'typer[all]>=0.3.2,<0.4.0']

entry_points = \
{'console_scripts': ['zebraodqa = zebraodqa.main:app']}

setup_kwargs = {
    'name': 'zebraodqa',
    'version': '0.0.1',
    'description': '',
    'long_description': '# ZebraODQA\nUtility tool',
    'author': 'Benjamin, Andreas',
    'author_email': None,
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.6.2,<4.0',
}


setup(**setup_kwargs)
